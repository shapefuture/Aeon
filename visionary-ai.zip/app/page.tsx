import { AeonLanding } from "@/components/aeon-landing"

export default function Home() {
  return <AeonLanding />
}
